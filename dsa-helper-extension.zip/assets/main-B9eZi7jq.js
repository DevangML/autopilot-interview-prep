import{c as t,j as e,r,I as o}from"./InterviewPrepApp-C2uET5pi.js";t.createRoot(document.getElementById("root")).render(e.jsx(r.StrictMode,{children:e.jsx(o,{})}));
