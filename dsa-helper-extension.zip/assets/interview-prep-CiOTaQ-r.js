import{c as r,j as e,r as t,I as o}from"./InterviewPrepApp-C2uET5pi.js";r.createRoot(document.getElementById("interview-prep-root")).render(e.jsx(t.StrictMode,{children:e.jsx(o,{})}));
