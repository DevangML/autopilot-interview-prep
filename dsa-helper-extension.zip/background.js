chrome.runtime.onInstalled.addListener(()=>{console.log("DSA Helper Extension installed")});
